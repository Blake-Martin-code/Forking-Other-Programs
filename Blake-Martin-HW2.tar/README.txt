README file for hw2

compile program using:

        make

clean the directory using:

        make clean

Run program using:

        ./Starter filename

        - file must only have 1 number per line


Starter.c
        This contains the main function for the entire program that opens and parses the 
        text file. Then calls a function on the numbers which then forks and executes the other 
        object files
Fibb.c
        This prints out the first n numbers of the fibbonacci sequence
Prime.c 
        this prints out the first n prime numbers 
Total.c 
        this prints out the sum of all the numbers within the given number
        for 5 the sum is 15, 0 + 1 + 2 + 3 + 4 + 5 = 15


Questions:

1. WEXITSTATUS returns the 8 least significant bits

2. WEXITSTATUS needs <sys/wait.h>

3. Upon a completion that is successful, Fork will return 0 to the child process and will also 
    return the process ID of the child process. If there was a failure to fork then it will return -1

4. If fork tries to create a process that would cause they system process limit to be exceeded 
    then that is a possibility that the fork will fail

5. We are doing sequential processing because before the next child process starts running it has to wait for the first one to complete

6. Yes there are anomalies when it comes to the WEXITSTATUS return value for when the input reaches a certain value.
    WEXITSTATUS only returns the 8 LS Bits which means a max value of 256 so if a value greater than 256 is supposed to be returned
    it only returns the 8 LS Bits of that number.