#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>


int Fibb(char* s){
    int n = atoi(s);
    printf("Fibb[%d] : Number of terms in fibonacii series is %d\n", getpid(), n);
    printf("Fibb[%d] : The first %d numbers of the Fibonacci sequence are:\n", getpid(), n);
    // if n == 1 then you only need  to print 0
    if(n == 1){
        printf("%d, \n", 0);
        return n;
    }
    int previousFib = 0, currentFib = 1;
    int newFib = 0;
    // print the first 2 numbers in the squence 0 and 1
    printf("%d, %d, ", previousFib, currentFib);
    for (int i = 2; i < n; i++)
    {
        // the new fib is the previous 2 fibs added together
        newFib = previousFib + currentFib;
        // if we are on the last fib # then print it out aswell as a 
        // new line and return the last fib #
        if(i == n - 1){
            printf("%d, \n", newFib);
            return newFib;
        }
        // if it is not the last fib # then just print out the fib number
        else printf("%d, ", newFib);
        // update the previous fib which is the current fib for next iteration
        previousFib = currentFib;
        // update the current fib which is now the new fib for next iteration
        currentFib = newFib;

    }
    
    printf("\n");
    return newFib;

}

int main(int argc, char *argv[]){
    return Fibb(argv[1]);
    
}
