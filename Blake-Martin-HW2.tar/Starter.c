#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>     
#include <stdio.h>
#include <sys/wait.h>
/*#include "Fibb.c"
#include "Prime.c"
#include "Total.c"*/  



void execute(char line[], int *fibb, int *prime, int *totalC){

    //fork a child process
    pid_t cid = fork();
    int id1 = getpid();
    int id2 = getppid();

    if (cid < 0) { /* error occurred */
        fprintf(stderr, "Fork Failed\n");
        exit(1);
    }
    else if (cid == 0) { /* child process */
    
        printf("Starter[%d] : Forked process with ID %d.\n", id2, id1);
        printf("Starter[%d] : Waiting for process [%d].\n", id2, id1);
        // execute the Fibb object file
        execlp("./Fibb.o","./Fibb.o", line, NULL);
    }
    else { /*parent will wait for the child to complete */
        int wstatus;
        wait(&wstatus);
        *fibb = WEXITSTATUS(wstatus);
        int temp = (int) *fibb;
        printf("Starter: Child process %d returned %d.\n", cid, temp);
    }


    // The below code creates a new child process and calls execlp() 
    // to run the prime.o object file

    cid = fork();
    id1 = getpid();
    id2 = getppid();
    if (cid < 0) { /* error occurred */
        fprintf(stderr, "Fork Failed\n");
        exit(1);
    }
    else if (cid == 0) { /* child process */
    
        printf("Starter[%d] : Forked process with ID %d.\n", id2, id1);
        printf("Starter[%d] : Waiting for process [%d].\n", id2, id1);
        // execute the Prime object file
        execlp("./Prime.o","./Prime.o", line, NULL);
    }
    else { /*parent will wait for the child to complete */
        int wstatus;
        wait(&wstatus);
        *prime = WEXITSTATUS(wstatus);
        int temp = (int) *prime;
        printf("Starter: Child process %d returned %d.\n", cid, temp);
    }

    // The below code creates a new child process and calls execlp() 
    // to run the total.o object file

    cid = fork();
    id1 = getpid();
    id2 = getppid();
    if (cid < 0) { /* error occurred */
        fprintf(stderr, "Fork Failed\n");
        exit(1);
    }
    else if (cid == 0) { /* child process */
    
        printf("Starter[%d] : Forked process with ID %d.\n", id2, id1);
        printf("Starter[%d] : Waiting for process [%d].\n", id2, id1);
        // execute the Total object file
        execlp("./Total.o","./Total.o", line, NULL);
    }
    else { /*parent will wait for the child to complete */
        int wstatus;
        wait(&wstatus);
        *totalC = WEXITSTATUS(wstatus);
        int temp = (int) *totalC;
        printf("Starter: Child process %d returned %d.\n", cid, temp);
    }
    

}


int main(int argc, char *argv[]){
    // make sure that there is only one argument passed
    // if argc is anything but 2 throw an error
    if (argc < 2){
        printf("Error: Too few arguments passed.\n");
        exit(0);
    }
    if(argc > 2){
        printf("Error: Too many arguments passed.\n");
        exit(0);
    }

    // create a file ptr and file name variable
    FILE *file_ptr;
    char* file_name = argv[1];
    // open file for reading only
    file_ptr = fopen(file_name, "r");
    // check to make sure it was opened properly
    if (!file_ptr){
        printf("Error: File failed to open.");
        exit(0);
    }

     int fibb = 0, prime = 0, totalC = 0;

    // create a pointer to an array of chars where each line will be read to
    char line[255];
    // get each line of the file
    while(fgets(line, 5, file_ptr) != NULL){
        // call execute on each line of the file
        execute(line, &fibb, &prime, &totalC);
    }

    printf("fibb: %d\n", fibb);
    printf("Prime: %d\n", prime);
    printf("total Count: %d\n", totalC);

    return 1;
}