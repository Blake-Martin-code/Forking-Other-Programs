#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>

int prime(char* s){
    int n = atoi(s);
    printf("Prime[%d] : First %d prime numbers are:\n", getpid(), n);
    int  i,p,count,flag;
    p=2;
    i=1; 

    // While the number of prime numbers found is less than 
    // or equal to the number of prime numbers wanted
    while(i<=n){
        flag=1;

        // starting at 2(first prime number) increment count looking for 
        // the next prime number
        for(count=2;count<=p-1;count++){
            // if p is not prime change flag to 0 and break
            if(p%count==0){
             flag=0;
             break;  
            }  
        }
        // if p is prime then print out the number and increment i so we know
        // that we found the next prime number. 
            if(flag==1){
                printf("%d, ",p) ;
             i++;
            }
        // increment p which is the next number to be tested if it is prime
        p++;
    }

    printf("\n");
    return p-1;
}


int main(int argc, char *argv[]){
    return prime(argv[1]);
    
}