#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>




int total(char* s){
    int num = atoi(s);
    int sum = 0;

    // count up to 5, adding all the digits into sum
    for(int i = 1; i <= num; i++){
        sum += i;
    }

    printf("Total[%d] : Sum = %d\n", getpid(), sum);
    return sum;
    
}


int main(int argc, char *argv[]){
    return total(argv[1]);

}

